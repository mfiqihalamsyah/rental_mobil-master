<?php
/*
  | Source Code Aplikasi Rental Mobil PHP & MySQL
  | 
  | @package   : rental_mobil
  | @file	   : kontak.php 
  | @author    : faqoy@gmail.com
  | 
  | 
  | 
  | 
 */
session_start();
require 'koneksi/koneksi.php';
include 'header.php';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Kontak Kami</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>

<body style="margin: 0;">
    <div>
        <section>
            <div class="container">
                <!-- about -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h2 class="display-4 fw-bolder"><span class="text-gradient d-inline">Kontak Kami</span></h2>
                        <p class="lead fw-light mb-4">Anda membutuhkan jasa rental / sewa mobil di Bekasi? Segera hubungi kami untuk melakukan reservasi!</p>
                        <div class="d-flex justify-content-center">
                            <a class="text-gradient me-3" href="https://www.facebook.com/gunarentalmobil" target="_blank"><i class="bi bi-facebook fs-2 text-primary"></i></a>
                            <a class="text-gradient me-3" href="https://api.whatsapp.com/send?phone=<?= $info_web->telp; ?>&text=Hello%20Rental Mobil,%20%20Saya%20ingin%20menanyakan%20tentang%20" target="_blank"><i class="bi bi-whatsapp fs-2 text-primary"></i></a>
                            <a class="text-gradient me-3" href="https://instagram.com/gunarentalmobil" target="_blank"><i class="bi bi-instagram fs-2 text-primary"></i></a>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center mt-5">
                    <div class="col-lg-6">
                        <div class="card h-100 w-100">
                            <div class="card-header">
                                Kontak Kami
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-4">Nama Rental</div>
                                    <div class="col-sm-8"><?= $info_web->nama_rental; ?></div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-sm-4">Telp</div>
                                    <div class="col-sm-8"><?= $info_web->telp; ?></div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-sm-4">Alamat</div>
                                    <div class="col-sm-8"><?= $info_web->alamat; ?></div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-sm-4">Email</div>
                                    <div class="col-sm-8"><?= $info_web->email; ?></div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-sm-4">No Rekening</div>
                                    <div class="col-sm-8"><?= $info_web->no_rek; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4 mt-lg-0">
                        <div class="card h-100 w-100">
                            <div class="card-header">
                                Lokasi Kami
                            </div>
                            <div class="card-body">
                                <div class="embed-responsive embed-responsive-16by9" style="height: 250px;">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.008192973912!2d106.9707126!3d-6.2487816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698c5204032a97%3A0x7dd864ce65061cd8!2sUniversitas%20Gunadarma%20Kampus%20J1!5e0!3m2!1sen!2sid!4v1567462454056!5m2!1sen!2sid" class="embed-responsive-item" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>
</body>

</html>

<?php include 'footer.php'; ?>