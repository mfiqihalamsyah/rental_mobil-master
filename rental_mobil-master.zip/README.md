Source Code Aplikasi Rental Mobil PHP & MySQL, tambah data, update / edit data, dan hapus data. User interface menggunakan Template Bootstrap. Aplikasi kali ini cocok untuk yang sedang belajar PHP & MySQL dasar, karena pada aplikasi ini anda dapat belajar tentang cara membuat login, kemudian membuat menu-menu yang terdapat pada bagian halaman admin seputar aplikasi, membuat CRUD data mobil, data transaksi booking dan lain nya.

## Fitur-fitur pada Aplikasi pada kali ini :

Login & Daftar Akun

- Modul Mobil
- Modul Booking
- Modul Peminjaman dan Pengembalian
- Informasi Website dan Aplikasi
- DLL

## Untuk Login Admin :

Username : admin
Password : demo

## Untuk Login Pengguna :

Username : demo
Password : demo

## Screenshot

<img src="https://www.codekop.com/storage/filemanager/1/6cab9b2bfde09c7e213ebe73e4e2f183.png">
<img src="https://www.codekop.com/storage/filemanager/1/2a668eed571730442eca9b29781d09d3.png">
<img src="https://www.codekop.com/storage/filemanager/1/25694806a4bc2da906303abf185853a6.png">
<img src="https://www.codekop.com/storage/filemanager/1/414f52327e86fb3421f1d16d8960b41b.png">
<img src="https://www.codekop.com/storage/filemanager/1/e2fba4822340ec35eb87de637ad4d79d.png">
